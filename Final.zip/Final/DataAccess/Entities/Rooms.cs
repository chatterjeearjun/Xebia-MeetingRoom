﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
    public class Rooms
    {
        public int RoomID { get; set; }
        public string RoomName { get; set; }
    }
}
