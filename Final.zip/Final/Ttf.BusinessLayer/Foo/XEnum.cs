﻿namespace Ttf.BusinessLayer.Foo
{
    public enum XEnum
    {
        S,
        R,
        T
    }
}
